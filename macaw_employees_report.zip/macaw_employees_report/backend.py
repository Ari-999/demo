import sqlite3 as sql
from datetime import datetime

# Connect to SQLite
con = sql.connect('employee_details_1.db')

# Create a Connection
cur = con.cursor()

cur.execute('''
    CREATE TABLE IF NOT EXISTS employees (
        UID INTEGER PRIMARY KEY AUTOINCREMENT,
        UNAME TEXT,
        PROJECT TEXT,
        TASK TEXT,
        TASK_RANGE TEXT,
        PERFORMANCE TEXT,
        TOTAL_AREA TEXT,
        COMPLETED_AREA TEXT,
        COORDINATOR TEXT,
        DATE DATE
    )
''')
# Commit changes
con.commit()


# Close the connection
con.close()

def moderatordata():
    con = sql.connect("employee_details_1.db")
    cur = con.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS userpass(usr TEXT PRIMARY KEY,
        namem TEXT,
        password TEXT,
        emailm TEXT,
        contactno TEXT)""")
    con.commit()
    con.close()
moderatordata()




def addmoderator(idm, namem, password, emailm, contactno):
    con = sql.connect("employee_details_1.db")
    cur = con.cursor()
    cur.execute("""INSERT INTO userpass VALUES (:usr,:namem,:password,:emailm,:contactno)""",
                {'usr': idm, 'namem': namem, 'password': password, 'emailm': emailm, 'contactno': contactno})
    con.commit()
    con.close()


# addmoderator(69,"harsh","hd","fk@gmail.com",111)
# addmoderator(2,"gsgg","kl","fs@gmail.com",21)

def viewmoderator():
    con = sql.connect("employee_details_1.db")
    cur = con.cursor()
    cur.execute("SELECT * FROM userpass")
    rows = cur.fetchall()
    con.close()
    return rows


# print(viewmoderator())
def deleterecmoderator(idm):
    con = sql.connect("employee_details_1.db")
    cur = con.cursor()
    cur.execute("DELETE FROM userpass WHERE usr=:idm", {'idm': idm})
    con.commit()
    con.close()


def updaterecmoderator(idm, namem, password, emailm, contactno):
    con = sql.connect("employee_details_1.db")
    cur = con.cursor()
    cur.execute(
        "UPDATE userpass SET namem=:namem,password=:password,emailm=:emailm,contactno=:contactno WHERE idm=:idm",
        {'namem': namem, 'password': password, 'emailm': emailm, 'contactno': contactno, 'idm': idm})
    con.commit()
    con.close()


# print(viewmoderator())




