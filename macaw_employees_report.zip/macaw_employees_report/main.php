<?php
use Flask\Flask;
use Flask\render_template;
use Flask\request;
use Flask\redirect;
use Flask\url_for;
use Flask\flash;
use Flask\send_file;
use Flask\session;
use sqlite3 as sql;
use DateTime;
use pandas as pd;
use IO\BytesIO;
use backend;
use staatiiicc\stic\Employee;

$app = new Flask(__name__);

<?php

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Session\Session;

$app->route('/', function (Request $request) use ($app) {
    if ($request->getMethod() === 'POST') {
        $x = $request->request->get('Uname');
        $y = $request->request->get('Pass');
        if ($x === $y && $x === 'macaw2468') {
            $app['session']->getFlashBag()->add('success', 'Admin login successful');
            $app['session']->set('username', $x);
            return $app->redirect($app['url_generator']->generate('admin_section'));
        } else {
            $data = backend::viewmoderator();
            print_r($data);
            foreach ($data as $lst) {
                if ((string)$lst[0] === (string)$x && (string)$lst[2] === (string)$y) {
                    $app['session']->getFlashBag()->add('success', 'User login successful');
                    $app['session']->set('username', $x);
                    return $app['twig']->render('add_user.html', ['mode' => $x]);
                }
            }
            $app['session']->getFlashBag()->add('error', 'Login failed');
            return $app['twig']->render('login.html');
        }
    }
    return $app['twig']->render('login.html', ['status' => 'get']);
});


<?php

use Symfony\Component\HttpFoundation\Session\Session;

$app->route('/adminsection', function () use ($app) {
    $session = new Session();
    if ($session->has('username')) {
        return $app['twig']->render('adminsection.html');
    } else {
        return $app->redirect($app['url_generator']->generate('login'));
    }
});

