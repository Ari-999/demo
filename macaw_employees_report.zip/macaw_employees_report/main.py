from flask import Flask, render_template, request, redirect, url_for, flash, send_file, session
import sqlite3 as sql
from datetime import datetime
import pandas as pd
import os
from io import BytesIO
from flask import send_file
import backend
from staatiiicc.stic import Employee

app = Flask(__name__)

@app.route("/", methods=["POST", "GET"])
def home():
    if request.method == "POST":
        x = request.form["Uname"]
        y = request.form['Pass']
        if x == y and x == "macaw2468":
            # Admin login
            flash('Admin login successful', 'success')
            # Store the username in the session
            session['username'] = x
            return redirect(url_for('admin_section'))
        else:
            # Check if user exists
            data = backend.viewmoderator()
            print(data)
            for lst in data:
                if str(lst[0]) == str(x) and str(lst[2]) == str(y):
                    flash('User login successful', 'success')
                    # Store the username in the session
                    session['username'] = x
                    return render_template('add_user.html', mode=x)
            flash('Login failed', 'error')
            return render_template('login.html')
    return render_template('login.html', status='get')

@app.route("/adminsection")
def admin_section():
    if 'username' in session:
        return render_template('adminsection.html')
    else:
        return redirect(url_for('login'))


@app.route('/add_employee', methods=["POST", "GET"])
def moderator():
    if request.method == "POST":
        idd = request.form['mod_id']
        name = request.form['Inputname']
        paswd = request.form['exampleInputPassword1']
        email = request.form['exampleInputEmail1']
        phone = request.form['num']
        print(type(phone), "****************************")
        if len(str(phone)) != 10:
            return render_template('add_employee.html', msg="phone")
        try:
            backend.addmoderator(idd, name, paswd, str(email), phone)
            return render_template('add_employee.html', msg="success")
        except Exception as e:
            print(e, "========================================")

            return render_template('add_employee.html', msg="error")

        print(viewmoderator())

    return render_template('add_employee.html', msg="GET")

@app.route('/viewmoddata', methods=["POST", "GET"])
def view_mod_data():
    userpass_data = backend.viewmoderator()

    if request.method == "POST":
        mod = request.form['mod_del']
        print(mod, "==============")
        backend.deleterecmoderator(mod)

    return render_template('delete_employee.html', data=userpass_data, length=len(userpass_data))


@app.route('/employee_login', methods=["POST", "GET"])
def modesection():
    nam = "Moderator"
    if request.method == "POST":
        nam = str(request.form['Uname'])
    return render_template('employee_login.html', mode=nam)


def index(request):
    current_date_data = Employee.objects.get_current_date_data()
    return render_template(request, 'index.html', {'datas': current_date_data})
# Employee Report

@app.route('/add_user', methods=["POST", "GET"])
def add_user():
    if request.method == 'POST':
        report_date = request.form['report_date']
        uname = session.get('username')  # Retrieve the username from the session
        project = request.form['project']
        task = request.form['task']
        task_range = request.form['task_range']
        performance = request.form['performance']
        total_area = request.form['total_area']
        completed_area = request.form['completed_area']

        con = sql.connect("employee_details_1.db")
        cur = con.cursor()

        # Check if a record with the same username and date already exists
        cur.execute("SELECT * FROM employees WHERE UNAME=? AND DATE=?", (uname, report_date))
        existing_record = cur.fetchone()

        if existing_record:
            flash('A report for this user on the selected date already exists.', 'error')
        else:
            # Insert the new record
            cur.execute("INSERT INTO employees (UNAME, PROJECT, TASK, TASK_RANGE, PERFORMANCE, TOTAL_AREA, COMPLETED_AREA, DATE) VALUES (?,?,?,?,?,?,?,?)",
                        (uname, project, task, task_range, performance, total_area, completed_area, report_date))
            con.commit()
            flash('Report Added', 'success')

        return redirect(url_for("home"))

    return render_template("login.html")

@app.route('/fetch_reports', methods=["GET", "POST"])
def fetch_reports():
    con = sql.connect("employee_details_1.db")
    con.row_factory = sql.Row
    cur = con.cursor()

    # Check if a search query and search option are submitted
    search_query = request.form.get('search_query')
    search_option = request.form.get('search_option')

    if search_query and search_option:
        # Define the SQL query based on the search option
        if search_option == "name":
            sql_query = "SELECT * FROM employees WHERE UNAME LIKE ? ORDER BY DATE"
        elif search_option == "date":
            sql_query = "SELECT * FROM employees WHERE DATE LIKE ? ORDER BY DATE"
        elif search_option == "month":
            sql_query = "SELECT * FROM employees WHERE strftime('%m', DATE) LIKE ? ORDER BY DATE"
        elif search_option == "project":
            sql_query = "SELECT * FROM employees WHERE PROJECT LIKE ? ORDER BY DATE"
        else:
            # Default to searching by name if the option is not recognized
            sql_query = "SELECT * FROM employees WHERE UNAME LIKE ? ORDER BY DATE"

        # Execute the SQL query
        cur.execute(sql_query, ('%' + search_query + '%',))

        data = cur.fetchall()
    else:
        # If no search query is provided, fetch all records
        cur.execute("SELECT * FROM employees ORDER BY DATE")
        data = cur.fetchall()

    download_link = False
    if data:
        download_link = True

    return render_template("fetch_reports.html", reports=data, search_query=search_query, search_option=search_option,
                           download_link=download_link)


@app.route('/download_excel', methods=['GET'])
def download_excel():
    search_query = request.args.get('search_query')
    search_option = request.args.get('search_option')

    con = sql.connect("employee_details_1.db")
    con.row_factory = sql.Row
    cur = con.cursor()

    if search_query and search_option:
        if search_option == "name":
            sql_query = "SELECT * FROM employees WHERE UNAME LIKE ? ORDER BY DATE"
        elif search_option == "date":
            sql_query = "SELECT * FROM employees WHERE DATE LIKE ? ORDER BY DATE"
        elif search_option == "month":
            sql_query = "SELECT * FROM employees WHERE strftime('%m', DATE) LIKE ? ORDER BY DATE"
        elif search_option == "project":
            sql_query = "SELECT * FROM employees WHERE PROJECT LIKE ? ORDER BY DATE"
        else:
            sql_query = "SELECT * FROM employees WHERE UNAME LIKE ? ORDER BY DATE"

        cur.execute(sql_query, ('%' + search_query + '%',))
        data = cur.fetchall()

        if data:
            df = pd.DataFrame(data)

            # Add a new column for serial numbers (incrementing row numbers)
            df.insert(0, 'Sno', range(1, 1 + len(df)))

            # Define the table headers
            table_headers = ['Sno','Reporting Sno', 'Employee Name', 'Project', 'Task', 'Task Range', 'Performance', 'Total Area',
                             'Completed Area', 'Coordinator','Date']

            excel_file = BytesIO()
            excel_writer = pd.ExcelWriter(excel_file, engine='xlsxwriter')
            df.to_excel(excel_writer, index=False, sheet_name='Search Results')
            worksheet = excel_writer.sheets['Search Results']

            # Write table headers to the Excel file
            for col_num, header in enumerate(table_headers):
                worksheet.write(0, col_num, header, excel_writer.book.add_format({'bold': True}))

            excel_writer.save()
            excel_file.seek(0)

            excel_filename = "search_results.xlsx"

            response = send_file(
                excel_file,
                as_attachment=True,
                download_name=excel_filename,
                mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )

            return response

    return "No search results available"


@app.route("/edit_user/<string:uid>", methods=['POST', 'GET'])
def edit_user(uid):
    if request.method == 'POST':
        uname = request.form['uname']
        project = request.form['project']
        task = request.form['task']
        task_range = request.form['task_range']
        performance = request.form['performance']
        total_area = request.form['total_area']
        completed_area = request.form['completed_area']

        coordinator = request.form['coordinator']

        con = sql.connect("employee_details_1.db")
        cur = con.cursor()
        cur.execute("UPDATE employees SET UNAME=?, PROJECT=?, TASK=?, TASK_RANGE=?, PERFORMANCE=?,TOTAL_AREA=?,COMPLETED_AREA=?, COORDINATOR=? WHERE UID=?",
                    (uname, project, task, task_range, performance,total_area,completed_area, coordinator, uid))
        con.commit()
        flash('User Updated', 'success')
        return redirect(url_for("index"))

    con = sql.connect("employee_details_1.db")
    con.row_factory = sql.Row
    cur = con.cursor()
    cur.execute("SELECT * FROM employees WHERE UID=?", (uid,))
    data = cur.fetchone()
    return render_template("edit_user.html", datas=data)


@app.route("/delete_user/<string:uid>", methods=['GET'])
def delete_user(uid):
    con = sql.connect("employee_details_1.db")
    cur = con.cursor()
    cur.execute("DELETE FROM employees WHERE UID=?", (uid,))
    con.commit()
    flash('User Deleted', 'warning')
    return redirect(url_for("index"))


@app.route("/generate_excel_month")
def generate_monthly_excel():
    con = sql.connect("employee_details_1.db")
    con.row_factory = sql.Row
    cur = con.cursor()

    # Retrieve all data from the 'employees' table
    cur.execute("SELECT * FROM employees")
    data = cur.fetchall()

    # Convert the data to a Pandas DataFrame
    df = pd.DataFrame(data, columns=[desc[0] for desc in cur.description])
    df.insert(0, 'Sno', range(1, 1 + len(df)))

    # Create a BytesIO object to write the Excel file
    excel_file = BytesIO()
    excel_writer = pd.ExcelWriter(excel_file, engine='xlsxwriter')
    df.to_excel(excel_writer, index=False, sheet_name='Employees')
    excel_writer.save()
    excel_file.seek(0)

    # Set the download filename
    today = datetime .now()
    excel_filename = f"employee_report_{today.strftime('%Y-%m-%d')}.xlsx"

    response = send_file(
        excel_file,
        as_attachment=True,
        download_name=excel_filename,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )

    return response



@app.route("/generate_excel")
def generate_daily_excel():
    con = sql.connect("employee_details_1.db")
    con.row_factory = sql.Row
    cur = con.cursor()

    # Get the current date in 'YYYY-MM-DD' format
    today = datetime.now().strftime('%Y-%m-%d')

    # Retrieve data for the current date from the 'employees' table
    cur.execute("SELECT * FROM employees WHERE DATE = ?", (today,))
    data = cur.fetchall()

    if data:
        # Convert the data to a Pandas DataFrame
        df = pd.DataFrame(data, columns=[desc[0] for desc in cur.description])
        df.insert(0, 'Sno', range(1, 1 + len(df)))

        # Create a BytesIO object to write the Excel file
        excel_file = BytesIO()
        excel_writer = pd.ExcelWriter(excel_file, engine='xlsxwriter')
        df.to_excel(excel_writer, index=False, sheet_name='Employees')
        excel_writer.save()
        excel_file.seek(0)

        # Set the download filename with the current date
        excel_filename = f"employee_report_{today}.xlsx"

        response = send_file(
            excel_file,
            as_attachment=True,
            download_name=excel_filename,
            mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        )

        return response

    return "No data available for today."


if __name__ == '__main__':
    app.secret_key="Ari123"
    app.run(host='0.0.0.0', port=5000, debug=True, threaded=True)


